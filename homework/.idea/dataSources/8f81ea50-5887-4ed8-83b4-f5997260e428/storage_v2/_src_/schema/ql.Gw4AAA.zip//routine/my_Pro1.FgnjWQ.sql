create
    definer = root@`%` procedure my_Pro1()
select * from my_student;

