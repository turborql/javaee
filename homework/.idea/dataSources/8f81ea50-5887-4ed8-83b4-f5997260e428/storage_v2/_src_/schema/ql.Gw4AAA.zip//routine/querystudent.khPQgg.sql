create
    definer = root@`%` procedure querystudent()
begin
select * from stu_info1;
end;

