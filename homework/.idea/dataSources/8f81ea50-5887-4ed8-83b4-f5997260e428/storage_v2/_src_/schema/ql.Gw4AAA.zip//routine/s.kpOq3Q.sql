create
    definer = root@`%` procedure s(IN ida int, OUT agea int)
begin
select age into agea from stu_info1 where id=ida;
end;

