create
    definer = root@`%` procedure stu(IN a int)
begin update stu_info1 set age=age+1 where id=a; end;

